from .census import CENSUS_CATALOG, get_theme_spec as get_census_spec
from .rais import get_rais_spec
from .cnes import get_cnes_spec
from .inep import get_schools_spec